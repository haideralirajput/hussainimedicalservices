<?php
// session_start();
include("conn.php");
$con=mysqli_connect("localhost","root","","myhmsdb");
// if(isset($_POST['submit'])){
//  $username=$_POST['username'];
//  $password=$_POST['password'];
//  $query="select * from logintb where username='$username' and password='$password';";
//  $result=mysqli_query($con,$query);
//  if(mysqli_num_rows($result)==1)
//  {
//   $_SESSION['username']=$username;
//   $_SESSION['pid']=
//   header("Location:admin-panel.php");
//  }
//  else
//   header("Location:error.php");
// }
if(isset($_POST['update_data']))
{
 $contact=$_POST['contact'];
 $status=$_POST['status'];
 $query="update appointmenttb set payment='$status' where contact='$contact';";
 $result=mysqli_query($con,$query);
 if($result)
  header("Location:updated.php");
}

// function display_docs()
// {
//  global $con;
//  $query="select * from doctb";
//  $result=mysqli_query($con,$query);
//  while($row=mysqli_fetch_array($result))
//  {
//   $username=$row['username'];
//   $price=$row['docFees'];
//   echo '<option value="' .$username. '" data-value="'.$price.'">'.$username.'</option>';
//  }
// }

// function display_s() {
//   global $conn;
//   $insert = "SELECT DISTINCT Specialization FROM doctor";
//   $result = mysqli_query($conn, $insert);
//   while ($row = mysqli_fetch_array($result)) {
//     $ds = $row['Specialization'];
//     echo '<option data-value="'.$ds.'">'.$ds.'</option>';
//   }
// }

// function display_docs() {
//   global $conn;
//   $insert = "SELECT CONCAT(FirstName, ' ', LastName) AS FullName, Specialization, Fees FROM doctor";
//   $result = mysqli_query($conn, $insert);
//   while ($row = mysqli_fetch_array($result)) {
//     $dname = $row['FullName'];
//     $dfees = $row['Fees'];
//     $ds = $row['Specialization'];
//     echo '<option value="' .$dname. '" data-value="'.$dfees.'" data-spec="'.$ds.'">'.$dname.'</option>';
//   }
// }
// function display_s() {
//   global $conn;
//   $insert="select distinct(Specialization) from doctor";
//   $result=mysqli_query($conn,$insert);
//   while($row=mysqli_fetch_array($result))
//   {
//     $ds=$row['Specialization'];
//     echo '<option data-value="'.$ds.'">'.$ds.'</option>';
//   }
// }

// function display_docs()
// {
//  global $conn;
// //  $insert = "select * from doctor";
//    $insert = "SELECT CONCAT(FirstName, ' ', LastName) AS FullName, Specialization, Fees FROM doctor";
//  $result = mysqli_query($conn,$insert);
//  while( $row = mysqli_fetch_array($result) )
//  {
//   $dname = $row['FullName'];
//   $dfees = $row['Fees'];
//   $ds = $row['Specialization'];
//   echo '<option value="' .$dname. '" data-value="'.$dfees.'" data-spec="'.$ds.'">'.$dname.'</option>';
//  }
// }


// function display_specs() {
//   global $con;
//   $query = "select distinct(spec) from doctb";
//   $result = mysqli_query($con,$query);
//   while($row = mysqli_fetch_array($result))
//   {
//     $spec = $row['spec'];
//     $username = $row['username'];
//     echo '<option value = "' .$spec. '">'.$spec.'</option>';
//   }
// }


if(isset($_POST['doc_sub']))
{
 $dname= $_POST['FirstName'." ". 'LastName'];
 $query="insert into doctor('FirstName')values('$dname')";
 $result=mysqli_query($conn,$query);
 if($result)
  header("Location:adddoc.php");
}

?>