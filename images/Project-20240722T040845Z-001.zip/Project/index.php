<?php
include('conn.php');
if (isset($_POST['PatientReg'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $password = base64_encode($_POST['password']);
    $contact = $_POST['contact'];
    $insert = "INSERT INTO `patients`(`FirstName`, `LastName`,`Gender`, `PhoneNumber`, `Email`, `Password`) VALUES
     ('$fname','$lname','$gender','$contact','$email','$password')";
    $result = mysqli_query($conn, $insert);
    if ($result) {
        echo "<script>alert('Your data is successfully inserted')</script>";
    }
}
if (isset($_POST['DoctorReg'])) {
    $dfname = $_POST['dfname'];
    $dlname = $_POST['dlname'];
    $dgender = $_POST['dgender'];
    $demail = $_POST['demail'];
    $ds = $_POST['ds'];
    $city = $_POST['cities'];
    $fees = $_POST['dfees'];
    $dpassword = base64_encode($_POST['dpassword']);
    $dcontact = $_POST['dcontact'];
    
    echo "<script>console.log('Form Data:', {
        dfname: '$dfname',
        dlname: '$dlname',
        dgender: '$dgender',
        demail: '$demail',
        ds: '$ds',
        city: '$city',
        fees: '$fees',
        dpassword: '$dpassword',
        dcontact: '$dcontact'
    });</script>";

    $dinsert = "INSERT INTO doctor (FirstName, LastName, Gender, Specialization, City, Fees, PhoneNumber, Email, Password) 
                VALUES ('$dfname', '$dlname', '$dgender', '$ds', '$city', '$fees', '$dcontact', '$demail', '$dpassword')";
    
    $result = mysqli_query($conn, $dinsert);
    if ($result) {
        echo "<script>alert('Your data is successfully inserted');</script>";
    } else {
        $error = mysqli_error($conn);
        echo "<script>alert('Your data is not successfully inserted. Error: " . addslashes($error) . "');</script>";
    }
} 

if (isset($_POST['AdminReg'])) {
    $afname = $_POST['afname'];
    $alname = $_POST['alname'];
    $agender = $_POST['agender'];
    $aemail = $_POST['aemail'];
    $apassword = base64_encode($_POST['apassword']);
    $acontact = $_POST['acontact'];
    $ainsert = "INSERT INTO `admins`(`FirstName`, `LastName`,`Gender`,`PhoneNumber`, `Email`, `Password`) VALUES ('$afname','$alname','$agender','$acontact','$aemail','$apassword')";

    $result = mysqli_query($conn, $ainsert);
    if ($result) {
        echo "<script>alert('Your data is successfully inserted')</script>";
    } else {
        echo "<script>alert('Your data is not successfully inserted')</script>";
    }
}
?>
<html>

<head>
    <title>Hussaini Medical Services</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
    <link rel="stylesheet" type="text/css" href="style1.css">
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style>
        .form-control {
            border-radius: 0.75rem;
        }
    </style>
</head>

<body>
    <!-- Navigation Bar is started -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="navbar">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="index.php" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;">
                <h4><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp Hussaini Medical Services</h4>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="index.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;">
                            <h6>HOME</h6>
                        </a>
                    </li>

                    <li class="nav-item" style="margin-right: 40px;">
                        <a class="nav-link js-scroll-trigger" href="services.html" style="color: white;font-family: 'IBM Plex Sans', sans-serif;">
                            <h6>ABOUT US</h6>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="contact.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;">
                            <h6>CONTACT</h6>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navigation bar is ended -->
    <div class="container register" style="font-family: 'IBM Plex Sans', sans-serif;">
        <div class="row">
            <div class="col-md-3 register-left" style="margin-top: 20%;right: 5%">
                <!-- <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt="" /> -->
                <h3>Welcome</h3>
            </div>
            <div class="col-md-9 register-right" style="margin-top: 60px;left: 80px;">
                <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist" style="width: 40%;">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Patient</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Doctor</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#admin" role="tab" aria-controls="admin" aria-selected="false">Admin</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                        <!-- Patient Registration -->
                        <h3 class="register-heading"> Register as Patient </h3>

                        <form method="post" action="">
                            <div class="row register-form">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="First Name *" name="fname" onkeydown="return alphaOnly(event);" required />
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="Your Email *" name="email" />
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password *" id="password" name="password" onkeyup='check();' required />
                                    </div>

                                    <div class="form-group">
                                        <div class="maxl">
                                            <label class="radio inline">
                                                <input type="radio" name="gender" value="Male" checked>
                                                <span> Male </span>
                                            </label>
                                            <label class="radio inline">
                                                <input type="radio" name="gender" value="Female">
                                                <span>Female </span>
                                            </label>
                                        </div>
                                        <a href="patientlogin.php">Already have an account?</a>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Last Name *" name="lname" onkeydown="return alphaOnly(event);" required />
                                    </div>

                                    <div class="form-group">
                                        <input type="tel" minlength="11" maxlength="12" name="contact" class="form-control" placeholder="Your Phone *" />
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="cpassword" placeholder="Confirm Password *" name="cpassword" onkeyup='check();' required /><span id='message'></span>
                                    </div>
                                    <input type="submit" class="btnRegister" name="PatientReg" onclick="return checklen();" value="Register" />
                                </div>

                            </div>
                        </form>
                    </div>
                    <!-- Doctor Registration -->

                    <div class="tab-pane fade show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                       <h3 class="register-heading">Register as Doctor</h3>
                        <form method="post" action="">
                            <div class="row register-form">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="First Name *" name="dfname" onkeydown="return dalphaOnly(event);" required />
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="Your Email *" name="demail" />
                                    </div>
                                    <div class="form-group">
                                        <select class="form-control" id="specialization" name="ds" required>
                                            <option value="">Select Specialization</option>
                                            <option value="Cardiology">Cardiology</option>
                                            <option value="Dermatology">Dermatology</option>
                                            <option value="Endocrinology">Endocrinology</option>
                                            <option value="Gastroenterology">Gastroenterology</option>
                                            <option value="Hematology">Hematology</option>
                                            <option value="Neurology">Neurology</option>
                                            <option value="Oncology">Oncology</option>
                                            <option value="Orthopedics">Orthopedics</option>
                                            <option value="Pediatrics">Pediatrics</option>
                                            <option value="Psychiatry">Psychiatry</option>
                                            <option value="Radiology">Radiology</option>
                                            <option value="Surgery">Surgery</option>
                                            <option value="Urology">Urology</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <select class="form-control" id="cities" name="cities" required>
                                            <option value="">Select Cities</option>
                                            <?php $sql = "SELECT city_name FROM cities";
                                            $result = mysqli_query($conn, $sql);

                                            if ($result) {

                                                while ($row = mysqli_fetch_array($result)) {
                                                    echo '<option value="' . $row['city_name'] . '">' . $row['city_name'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="">No Cities Available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password *" id="dpassword" name="dpassword" onkeyup='dcheck();' required />
                                    </div>

                                    <div class="form-group">
                                        <div class="maxl">
                                            <label class="radio inline">
                                                <input type="radio" name="dgender" value="Male" checked>
                                                <span> Male </span>
                                            </label>
                                            <label class="radio inline">
                                                <input type="radio" name="dgender" value="Female">
                                                <span>Female </span>
                                            </label>
                                        </div>
                                        <a href="doctorlogin.php">Already have an account?</a>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Last Name *" name="dlname" onkeydown="return dalphaOnly(event);" required />
                                    </div>

                                    <div class="form-group">
                                        <input type="tel" minlength="11" maxlength="12" name="dcontact" class="form-control" placeholder="Your Phone *" />
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Fees *" id="dfees" name="dfees" required />
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="dcpassword" placeholder="Confirm Password *" name="dcpassword" onkeyup='dcheck();' required /><span id='dmessage'></span>
                                    </div>
                                    <input type="submit" class="btnRegister" name="DoctorReg" onclick="return dchecklen();" value="Register" />
                                </div>

                            </div>
                         </form>


                    </div>
                    <!-- Admin Registration -->

                    <div class="tab-pane fade show" id="admin" role="tabpanel" aria-labelledby="profile-tab">
                        <h3 class="register-heading"> Register as Admin </h3>

                        <form method="post" action="">
                            <div class="row register-form">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="First Name *" name="afname" onkeydown="return aalphaOnly(event);" required />
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control" placeholder="Your Email *" name="aemail" />
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password *" id="apassword" name="apassword" onkeyup='acheck();' required />
                                    </div>

                                    <div class="form-group">
                                        <div class="maxl">
                                            <label class="radio inline">
                                                <input type="radio" name="agender" value="Male" checked>
                                                <span> Male </span>
                                            </label>
                                            <label class="radio inline">
                                                <input type="radio" name="agender" value="Female">
                                                <span>Female </span>
                                            </label>
                                        </div>
                                        <a href="adminlogin.php">Already have an account?</a>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Last Name *" name="alname" onkeydown="return aalphaOnly(event);" required />
                                    </div>

                                    <div class="form-group">
                                        <input type="tel" minlength="11" maxlength="12" name="acontact" class="form-control" placeholder="Your Phone *" />
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="acpassword" placeholder="Confirm Password *" name="cpassword" onkeyup='acheck();' required /><span id='amessage'></span>
                                    </div>
                                    <input type="submit" class="btnRegister" name="AdminReg" onclick="return achecklen();" value="Register" />
                                </div>

                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>

    </div>
    <script>
        var check = function() {
            if (document.getElementById('password').value ==
                document.getElementById('cpassword').value) {
                document.getElementById('message').style.color = '#5dd05d';
                document.getElementById('message').innerHTML = 'Matched';
            } else {
                document.getElementById('message').style.color = '#f55252';
                document.getElementById('message').innerHTML = 'Not Matching';
            }
        }

        function alphaOnly(event) {
            var key = event.keyCode;
            return ((key >= 65 && key <= 90) || key == 8 || key == 32);
        };

        function checklen() {
            var pass1 = document.getElementById("password");
            if (pass1.value.length < 8) {
                alert("Password must be at least 8 characters long. Try again!");
                return false;
            }
        }

        var dcheck = function() {
            if (document.getElementById('dpassword').value ==
                document.getElementById('dcpassword').value) {
                document.getElementById('dmessage').style.color = '#5dd05d';
                document.getElementById('dmessage').innerHTML = 'Matched';
            } else {
                document.getElementById('dmessage').style.color = '#f55252';
                document.getElementById('dmessage').innerHTML = 'Not Matching';
            }
        }

        function dalphaOnly(event) {
            var key = event.keyCode;
            return ((key >= 65 && key <= 90) || key == 8 || key == 32);
        };

        function dchecklen() {
            var pass1 = document.getElementById("dpassword");
            if (pass1.value.length < 8) {
                alert("Password must be at least 8 characters long. Try again!");
                return false;
            }
        }
        var acheck = function() {
            if (document.getElementById('apassword').value ==
                document.getElementById('acpassword').value) {
                document.getElementById('amessage').style.color = '#5dd05d';
                document.getElementById('amessage').innerHTML = 'Matched';
            } else {
                document.getElementById('amessage').style.color = '#f55252';
                document.getElementById('amessage').innerHTML = 'Not Matching';
            }
        }

        function aalphaOnly(event) {
            var key = event.keyCode;
            return ((key >= 65 && key <= 90) || key == 8 || key == 32);
        };

        function achecklen() {
            var pass1 = document.getElementById("apassword");
            if (pass1.value.length < 8) {
                alert("Password must be at least 8 characters long. Try again!");
                return false;
            }
        }
    </script>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>

</html>