<!DOCTYPE html>
<?php
session_start();
include("conn.php");
if (isset($_POST['doctorlogin'])) {
  $email =  $_POST['email'];
  $password = $_POST['password'];
  $query = "SELECT * FROM Doctor WHERE Email = '$email'";
  $result = mysqli_query($conn, $query);

  if ($result) {
    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_array($result);
      if ($password == base64_decode($row['Password'])) {

        $_SESSION['DoctorID'] = $row['0'];
        $_SESSION['dEmail'] = $row['Email'];
        $_SESSION['FirstName'] = $row['FirstName'];
        $_SESSION['LastName'] = $row['LastName'];
        header("Location: doctor-panel.php");
        exit();
      } else {
        echo "<script>alert('Invalid Password')</script>";
      }
    } else {
      echo "<script>alert('No user found with this email')</script>";
    }
  }
}
if (isset($_POST['doctorupdate'])) {
  $id = $_SESSION['DoctorID'];
  $dfname = $_POST['dfname'];
  $dlname = $_POST['dlname'];
  $dgender = $_POST['dgender'];
  $demail = $_POST['demail'];
  $ds = $_POST['ds'];
  $dc = $_POST['dcity'];

  $fees = $_POST['dfees'];
  $dpassword = base64_encode($_POST['dpassword']);
  $dcontact = $_POST['dcontact'];
  $dupdate = "UPDATE `doctor` SET `FirstName`='$dfname',`LastName`='$dlname',`Gender`='$dgender',`Specialization`='$ds',`City`='$dc',`Fees`='$fees',`PhoneNumber`='$dcontact',`Email`='$demail',`Password`='$dpassword' WHERE `DoctorID`='$id'";

  $result = mysqli_query($conn, $dupdate);
  if ($result) {
    echo "<script>alert('Your data is successfully updated')</script>";
  } else {
    echo "<script>alert('Your data is not successfully updated')</script>";
  }
}
$citiesQuery = "SELECT `city_name` FROM `cities`"; // Replace 'cities' with your actual table name
$citiesResult = mysqli_query($conn, $citiesQuery);
$cities = [];
if ($citiesResult) {
    while ($cityRow = mysqli_fetch_assoc($citiesResult)) {
        $cities[] = $cityRow['city_name'];
    }
}
$id = $_SESSION['DoctorID'];
$FirstName = $_SESSION['FirstName'];
$LastName = $_SESSION['LastName'];
if (isset($_GET['cancel'])) {
  $query = mysqli_query($conn, "update appointments set DoctorStatus='0' where AppointmentID = '" . $_GET['ID'] . "'");
  if ($query) {
    echo "<script>alert('Your appointment successfully cancelled');</script>";
  }
}

if (isset($_GET['approve'])) {
  $query = mysqli_query($conn, "update appointments set DoctorStatus='2' where AppointmentID = '" . $_GET['ID'] . "'");
  if ($query) {
    echo "<script>alert('Your appointment successfully approved');</script>";
  }
}
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
  <style>
    .btn-outline-light:hover {
      color: #25bef7;
      background-color: #f8f9fa;
      border-color: #f8f9fa;
    }
  </style>
  <style>
    .bg-primary {
      background: -webkit-linear-gradient(left, #3931af, #00c6ff);
    }
    .list-group-item.active {
      z-index: 2;
      color: #fff;
      background-color: #342ac1;
      border-color: #007bff;
    }
    .text-primary {
      color: #342ac1 !important;
    }
    button:hover {
      cursor: pointer;
    }
    #inputbtn:hover {
      cursor: pointer;
    }
  </style>
</head>
<body style="padding-top:50px;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> Global Hospital </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="logout1.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0" method="post" action="search.php">
        <input class="form-control mr-sm-2" type="text" placeholder="Enter contact number" aria-label="Search" name="contact">
        <input type="submit" class="btn btn-outline-light" id="inputbtn" name="search_submit" value="Search">
      </form>
    </div>
  </nav>
  <div class="container-fluid" style="margin-top:50px;">
    <h3 style="margin-left: 40%; padding-bottom: 20px;font-family:'IBM Plex Sans', sans-serif;"> Welcome
      &nbsp<?php echo "Dr " . $_SESSION['FirstName'] . " " . $_SESSION['LastName'] ?> </h3>
    <div class="row">
      <div class="col-md-4" style="max-width:18%;margin-top: 3%;">
        <div class="list-group" id="list-tab" role="tablist">
          <a class="list-group-item list-group-item-action active" href="#list-dash" role="tab" aria-controls="home" data-toggle="list">Dashboard</a>
          <a class="list-group-item list-group-item-action" href="#list-app" id="list-app-list" role="tab" data-toggle="list" aria-controls="home">Appointments</a>
          <a class="list-group-item list-group-item-action" href="#settings" id="doc_settings" role="tab" data-toggle="list" aria-controls="home">Settings</a>
        </div><br>
      </div>
      <div class="col-md-8" style="margin-top: 3%;">
        <div class="tab-content" id="nav-tabContent" style="width: 950px;">
          <div class="tab-pane fade show active" id="list-dash" role="tabpanel" aria-labelledby="list-dash-list">

            <div class="container-fluid container-fullw bg-white">
              <div class="row">

                <div class="col-md-6">
                  <div class="panel panel-white no-radius text-center ">
                    <div class="panel-body" style="font-size: 20px">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-list fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%; font-size: 30px"> View Appointments</h4>
                      <script>
                        function clickDiv(id) {
                          document.querySelector(id).click();
                        }
                      </script>
                      <p class="links cl-effect-1">
                        <a href="#list-app" onclick="clickDiv('#list-app-list')">
                          Appointment List
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body" style="font-size: 20px">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-gear fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%; font-size: 30px"> Settings</h4>
                      <script>
                        function clickDiv(id) {
                          document.querySelector(id).click();
                        }
                      </script>
                      <p class="links cl-effect-1">
                        <a href="#settings" onclick="clickDiv('#doc_settings')">
                          Settings
                        </a>
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <!-- Appointment List is started -->
          <div class="tab-pane fade" id="list-app" role="tabpanel" aria-labelledby="list-home-list">
            <table class="table table-hover">
              <thead>
                <tr class="text-center">
                  <th scope="col">Patient ID</th>
                  <th scope="col">Appointment ID</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Email</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Appointment Date</th>
                  <th scope="col">Appointment Time</th>
                  <th scope="col">Current Status</th>
                  <th scope="col" colspan="2">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $dname = $_SESSION['FirstName'] . " " . $_SESSION['LastName'];
                global $conn;
                $query = "SELECT PatientID, AppointmentID, FirstName, LastName, Gender, Email, PhoneNumber, Adate, Atime, PatientStatus, DoctorStatus
FROM appointments
WHERE DoctorName = '$dname' ;
;";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_array($result)) {
                ?>
                  <tr>
                    <td><?php echo $row['PatientID']; ?></td>
                    <td><?php echo $row['AppointmentID']; ?></td>
                    <td><?php echo $row['FirstName']; ?></td>
                    <td><?php echo $row['LastName']; ?></td>
                    <td><?php echo $row['Gender']; ?></td>
                    <td><?php echo $row['Email']; ?></td>
                    <td><?php echo $row['PhoneNumber']; ?></td>
                    <td><?php echo $row['Adate']; ?></td>
                    <td><?php echo $row['Atime']; ?></td>
                    <td>
                      <?php
                      if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) {
                        echo "Active";
                      } elseif (($row['PatientStatus'] == 0) && ($row['DoctorStatus'] == 1)) {
                        echo "Cancelled by Patient";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 0)) {
                        echo "Cancelled by You";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 2)) {
                        echo "Approved";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 3)) {
                        echo "Rescheduled";
                      } else {
                        echo "Unknown Status";
                      }
                      ?>
                    </td>

                    <td>
                      <?php if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) { ?>
                        <a href="doctor-panel.php?ID=<?php echo $row['AppointmentID'] ?>&approve=update" onClick="return confirm('Are you sure you want to approve this appointment ?')" title="Approve Appointment" tooltip-placement="top" tooltip="Approve"><button class="btn btn-success">Approve</button></a>
                      <?php } else {
                        echo "Taken";
                      } ?>

                    </td>
                    <td>
                      <?php if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) { ?>
                        <a href="doctor-panel.php?ID=<?php echo $row['AppointmentID'] ?>&cancel=update" onClick="return confirm('Are you sure you want to cancel this appointment ?')" title="Cancel Appointment" tooltip-placement="top" tooltip="Remove"><button class="btn btn-danger">Cancel</button></a>
                      <?php } else {
                        echo "Taken";
                      } ?>

                    </td>
                  </tr></a>
                <?php } ?>
              </tbody>
            </table>
            <br>
          </div>
          <!-- Appointment List is ended -->

          <!-- Settings is started -->
          <?php
          $updateread = "SELECT * FROM `doctor` WHERE `DoctorID` = '$id'";
          $resultupdate = mysqli_query($conn, $updateread);
          if ($resultupdate) {
            $row = mysqli_fetch_array($resultupdate);
          }
          ?>
          <div class="tab-pane fade" id="settings" role="tabpanel" aria-labelledby="list-home-list">

            <form action="" method="post">
              <div class="row register-form">

                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="First Name *" name="dfname" value="<?= $row['FirstName'] ?>" required />
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Your Email *" value="<?= $row['Email'] ?>" name="demail" />
                  </div>
                  <div class="form-group">
                    <select class="form-control" id="specialization" name="ds">
                      <option value="<?= $row['Specialization'] ?>"><?= $row['Specialization'] ?></option>
                    </select>
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Fees *" id="dfees" value="<?= $row['Fees'] ?>" name="dfees" required />
                  </div>
                  <div class="form-group">
                    <div class="maxl">
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Male" <?php if ($row['Gender'] == 'Male') {
                                                                          echo "checked";
                                                                        } ?>>
                        <span> Male </span>
                      </label>
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Female" <?php if ($row['Gender'] == 'Female') {
                                                                            echo "checked";
                                                                          } ?>>
                        <span>Female </span>
                      </label>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Last Name *" name="dlname" value="<?= $row['LastName'] ?>" required />
                  </div>

                  <div class="form-group">
                    <input type="tel" minlength="11" maxlength="12" name="dcontact" class="form-control" value="<?= $row['PhoneNumber'] ?>" placeholder="Your Phone *" />
                  </div>
                  <div class="form-group">
                    <select class="form-control" id="dc" name="dcity">
                        <option value="<?= $row['City'] ?>"><?= $row['City'] ?></option>
                        <?php foreach ($cities as $city): ?>
                            <option value="<?= $city ?>"><?= $city ?></option>
                        <?php endforeach; ?>
                    </select>               
                </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Password *" id="dpassword" name="dpassword" value="<?= base64_decode($row['Password']) ?>" onkeyup='dcheck();' required />
                  </div>
                </div>
                <div style="margin-left: 20px;">
                  <input type="submit" class="btn btn-primary" name="doctorupdate" onclick="return dchecklen();" value="Update" />
                </div>
              </div>
            </form>
          </div>
          <!-- Settings is ended -->
        </div>
      </div>
    </div>
  </div>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.1/sweetalert2.all.min.js"></script>
</body>

</html>