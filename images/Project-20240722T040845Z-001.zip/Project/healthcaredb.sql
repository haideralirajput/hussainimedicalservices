-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2024 at 06:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcaredb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `FirstName`, `LastName`, `Gender`, `PhoneNumber`, `Email`, `Password`) VALUES
(1, 'Fizza', 'Sohail', 'Female', '03112233112', 'fizza@gmail.com', '$2y$10$4wrne0HlRT8o6.wOYPo8nujegZoZCeEfF2MQuv0i8X4ga9afR6zS6'),
(2, 'Ali', 'Nawaz', 'Male', '03112233112', 'ali@gmail.com', '$2y$10$uS1uurtZMXEsxbqgexBHluEjG82DST8jMAuUVHqTBhUtwpZmknay2');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `AppointmentID` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Gender` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `DoctorID` int(11) NOT NULL,
  `DoctorName` varchar(255) NOT NULL,
  `DoctorFees` int(11) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `Adate` date NOT NULL,
  `Atime` time NOT NULL,
  `PatientStatus` int(11) DEFAULT NULL,
  `DoctorStatus` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`AppointmentID`, `PatientID`, `FirstName`, `LastName`, `Gender`, `Email`, `PhoneNumber`, `DoctorID`, `DoctorName`, `DoctorFees`, `City`, `Adate`, `Atime`, `PatientStatus`, `DoctorStatus`) VALUES
(1, 1, 'Ali', 'nawaz', 'Male', 'ali@gmail.com', '03002753890', 2, 'Sarkar Hussain', 1500, 'Islamabad', '2024-07-18', '12:00:00', 1, 2),
(3, 1, 'Ali', 'nawaz', 'Male', 'ali@gmail.com', '03002753890', 1, 'Hadi nawaz', 1100, 'Karachi', '2024-07-22', '14:00:00', 1, 0),
(4, 1, 'Ali', 'nawaz', 'Male', 'ali@gmail.com', '03002753891', 5, 'Ali Akbar', 7000, 'Hyderabad', '2024-07-22', '12:00:00', 1, 2),
(5, 1, 'Ali', 'nawaz', 'Male', 'ali@gmail.com', '03002753891', 5, 'Ali Akbar', 7000, 'Hyderabad', '2024-07-23', '10:00:00', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `city_name`) VALUES
(1, 'Karachi'),
(2, 'Hyderabad'),
(3, 'Islamabad'),
(4, 'Lahore'),
(5, 'Quetta');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `DoctorID` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Specialization` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `Fees` int(11) DEFAULT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`DoctorID`, `FirstName`, `LastName`, `Gender`, `Specialization`, `City`, `Fees`, `PhoneNumber`, `Email`, `Password`) VALUES
(5, 'Ali', 'Akbar', 'Male', 'Pediatrics', 'Hyderabad', 8000, '03111122334', 'ali@gmail.com', 'MTIzNDU2Nzk='),
(6, 'Ali', 'Abbas', 'Male', 'Oncology', 'Hyderabad', 5000, '03111122390', 'aliabbas@gmail.com', 'MTIzNDU2Nzg=');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `PatientID` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`PatientID`, `FirstName`, `LastName`, `Gender`, `PhoneNumber`, `Email`, `Password`) VALUES
(1, 'Ali', 'nawaz', 'Male', '03002753891', 'alikhan@gmail.com', 'YWxpMTIzNDU='),
(2, 'Hassan', 'nawaz', 'Male', '03111234567', 'hassan@gmail.com', 'aGFzc2FuMTIz'),
(4, 'Hadi', 'nawaz', 'Male', '03002753890', 'nawazhadi92@gmail.com', 'MTIzNDU2Nzg=');

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `Name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `PhoneNo` varchar(15) DEFAULT NULL,
  `Message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`Name`, `Email`, `PhoneNo`, `Message`) VALUES
('Hadi nawaz', 'haidali2509@gmail.com', '03112599191', ';;kl\';'),
('kl', 'haidali2509@gmail.com', '03002753890', '\''),
('Hadi nawaz', 'haidali2509@gmail.com', '03112599191', 'hjkhk'),
('Hadi nawaz', 'haidali2509@gmail.com', '03112599122', 'lk;j;;;;');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`AppointmentID`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`DoctorID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`PatientID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `AppointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `DoctorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `PatientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
