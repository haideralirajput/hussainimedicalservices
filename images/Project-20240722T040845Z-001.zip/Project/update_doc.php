<?php
include("conn.php");
if (isset($_GET['updatedoc'])) {

          $updateread = "SELECT * FROM `doctor` WHERE `DoctorID` = '" . $_GET['ID'] . "'";
          $resultupdate = mysqli_query($conn, $updateread);
          if ($resultupdate) {
            $row = mysqli_fetch_array($resultupdate);
          }
        }
if (isset($_POST['doctorupdate'])) {
  $dfname = $_POST['dfname'];
  $dlname = $_POST['dlname'];
  $dgender = $_POST['dgender'];
  $demail = $_POST['demail'];
  $ds = $_POST['ds'];
  $dc = $_POST['dcity'];

  $fees = $_POST['dfees'];
  $dpassword = base64_encode($_POST['dpassword']);
  $dcontact = $_POST['dcontact'];
  $dupdate = "UPDATE `doctor` SET `FirstName`='$dfname',`LastName`='$dlname',`Gender`='$dgender',`Specialization`='$ds',`City`='$dc',`Fees`='$fees',`PhoneNumber`='$dcontact',`Email`='$demail',`Password`='$dpassword' WHERE `DoctorID`='" . $_GET['ID'] . "'";

  $result = mysqli_query($conn, $dupdate);
  if ($result) {
    echo "<script>alert('Your data is successfully updated')
            window.location.href = 'admin-panel.php';

    </script>";

  } else {
    echo "<script>alert('Your data is not successfully updated')</script>";
  }
}
$citiesQuery = "SELECT `city_name` FROM `cities`"; // Replace 'cities' with your actual table name
$citiesResult = mysqli_query($conn, $citiesQuery);
$cities = [];
if ($citiesResult) {
    while ($cityRow = mysqli_fetch_assoc($citiesResult)) {
        $cities[] = $cityRow['city_name'];
    }
}     

?>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
  <style>
    .btn-outline-light:hover {
      color: #25bef7;
      background-color: #f8f9fa;
      border-color: #f8f9fa;
    }
  </style>

  <style>
    .bg-primary {
      background: -webkit-linear-gradient(left, #3931af, #00c6ff);
    }

    .list-group-item.active {
      z-index: 2;
      color: #fff;
      background-color: #342ac1;
      border-color: #007bff;
    }

    .text-primary {
      color: #342ac1 !important;

    }

    button:hover {
      cursor: pointer;
    }

    #inputbtn:hover {
      cursor: pointer;
    }
  </style>
</head>
<body style="padding-top:50px;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> Global Hospital </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="logout1.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
      </ul>
      <!-- <form class="form-inline my-2 my-lg-0" method="post" action="search.php">
        <input class="form-control mr-sm-2" type="text" placeholder="Enter contact number" aria-label="Search" name="contact">
        <input type="submit" class="btn btn-outline-light" id="inputbtn" name="search_submit" value="Search">
      </form> -->
    </div>
  </nav>

  <div class="container mt-5">
    <h2 class="text-center mb-5 text-primary">Update Doctor Information</h2>
            <form action="" method="post">
              <div class="row register-form">

                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="First Name *" name="dfname" value="<?= $row['FirstName'] ?>" required />
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Your Email *" value="<?= $row['Email'] ?>" name="demail" />
                  </div>
                  <div class="form-group">
                    <select class="form-control" id="specialization" name="ds">
                      <option value="<?= $row['Specialization'] ?>"><?= $row['Specialization'] ?></option>
                    </select>
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Fees *" id="dfees" value="<?= $row['Fees'] ?>" name="dfees" required />
                  </div>

                  <div class="form-group">
                    <div class="maxl">
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Male" <?php if ($row['Gender'] == 'Male') {
                                                                          echo "checked";
                                                                        } ?>>
                        <span> Male </span>
                      </label>
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Female" <?php if ($row['Gender'] == 'Female') {
                                                                            echo "checked";
                                                                          } ?>>
                        <span>Female </span>
                      </label>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Last Name *" name="dlname" value="<?= $row['LastName'] ?>" required />
                  </div>

                  <div class="form-group">
                    <input type="tel" minlength="11" maxlength="12" name="dcontact" class="form-control" value="<?= $row['PhoneNumber'] ?>" placeholder="Your Phone *" />
                  </div>
                  <div class="form-group">
                    <select class="form-control" id="dc" name="dcity">
                        <option value="<?= $row['City'] ?>"><?= $row['City'] ?></option>
                        <?php foreach ($cities as $city): ?>
                            <option value="<?= $city ?>"><?= $city ?></option>
                        <?php endforeach; ?>
                    </select>               
                </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Password *" id="dpassword" name="dpassword" value="<?= base64_decode($row['Password']) ?>" onkeyup='dcheck();' required />
                  </div>
                </div>
                <div style="margin-left: 20px;">
                  <input type="submit" class="btn btn-primary" name="doctorupdate" onclick="return dchecklen();" value="Update" />

                  <a href="admin-panel.php" class="btn btn-success" >Back</a>

    
                </div>

              </div>

            </form>
            </div>
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.1/sweetalert2.all.min.js"></script>
</body>

</html>