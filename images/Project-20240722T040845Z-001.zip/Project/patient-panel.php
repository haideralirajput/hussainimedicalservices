<!DOCTYPE html>
<?php
include("conn.php");
session_start();
include("conn.php");
if (isset($_POST['patientlogin'])) {
  $email =  $_POST['email'];
  $password = $_POST['password'];
  $query = "SELECT * FROM Patients WHERE Email = '$email'";
  $result = mysqli_query($conn, $query);

  if ($result) {
    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_array($result);
      if ($password == base64_decode($row['Password']))  {

        $_SESSION['PatientID'] = $row['0'];
        $_SESSION['FirstName'] = $row['FirstName'];
        $_SESSION['LastName'] = $row['LastName'];
        $_SESSION['username'] = $row['FirstName']." ".$row['LastName'];
        $_SESSION['Gender'] = $row['Gender'];
        $_SESSION['PhoneNumber'] = $row['PhoneNumber'];
        $_SESSION['Email'] = $row['Email'];
        header("Location: admin-panel.php");
        exit();
      } else {
        echo "<script>alert('Invalid Password')</script>";
      }
    }else {
        echo "<script>
        alert('No user found with this email');
        window.location.href = 'patientlogin.php';
        </script>";
    }
    
  }
}
$PatientID = $_SESSION['PatientID'];

$FirstName = $_SESSION['FirstName'];
$LastName = $_SESSION['LastName'];
if (isset($_POST['appsubmit'])) {
  if (session_status() == PHP_SESSION_NONE) {
    session_start();
  }
  error_reporting(E_ALL);
  ini_set('display_errors', 1);
  $PatientID = $_SESSION['PatientID'];
  $FirstName = $_SESSION['FirstName'];
  $LastName = $_SESSION['LastName'];
  $Gender = $_SESSION['Gender'];
  $PhoneNumber = $_SESSION['PhoneNumber'];
  $Email = $_SESSION['Email'];
  $DoctorID = $_POST['DoctorID'];
  $doctor = $_POST['dname'];
  $dFees = $_POST['dfees'];
  $dcity = $_POST['city'];
  $appdate = $_POST['appdate'];
  $apptime = $_POST['apptime'];
  $apptime1 = strtotime($apptime);
  $appdate1 = strtotime($appdate);
  date_default_timezone_set('Asia/Kolkata');
  $cur_date = date("Y-m-d");
  $cur_time = date("H:i:s");
  $stmt = $conn->prepare("INSERT INTO `appointments`(`PatientID`, `FirstName`, `LastName`, `Gender`, `Email`, `PhoneNumber`, `DoctorID`, `DoctorName`, `DoctorFees`,`City`, `Adate`, `Atime`, `PatientStatus`, `DoctorStatus`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, 1, 1)");
  if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
  }
  $stmt->bind_param("isssssisssss", $PatientID, $FirstName, $LastName, $Gender, $Email, $PhoneNumber, $DoctorID, $doctor, $dFees,$dcity, $appdate, $apptime);
  if ($stmt->execute()) {
    echo "<script>alert('Your appointment successfully booked');</script>";
  } else {
    echo "<script>alert('Unable to process your request. Please try again! Error: " . htmlspecialchars($stmt->error) . "');</script>";
  }
  // if (date("Y-m-d", $appdate1) >= $cur_date) {
  //   if ((date("Y-m-d", $appdate1) == $cur_date && date("H:i:s", $apptime1) > $cur_time) || date("Y-m-d", $appdate1) > $cur_date) {
  //       if ($stmt->execute()) {
  //           echo "<script>alert('Your appointment successfully booked');</script>";
  //       } else {
  //           echo "<script>alert('Unable to process your request. Please try again! Error: " . htmlspecialchars($stmt->error) . "');</script>";
  //       }
  //   } else {
  //       echo "<script>alert('We are sorry to inform that the doctor is not available at this time or date. Please choose a different time or date!');</script>";
  //   }
  // } else {
  //   echo "<script>alert('Select a time or date in the future!');</script>";
  // }
  $stmt->close();
}

if (isset($_GET['cancel'])) {
  $query = mysqli_query($conn, "update appointments set PatientStatus='0' where AppointmentID = '" . $_GET['ID'] . "'");
  if ($query) {
    echo "<script>alert('Your appointment successfully cancelled');</script>";
  }
}
if (isset($_POST['patupdate'])) {
  $dfname = $_POST['dfname'];
  $dlname = $_POST['dlname'];
  $dgender = $_POST['dgender'];
  $demail = $_POST['demail'];
  $dpassword = base64_encode($_POST['dpassword']);
  $dcontact = $_POST['dcontact'];
  $dupdate = "UPDATE `patients` SET `FirstName`='$dfname',`LastName`='$dlname',`Gender`='$dgender',`PhoneNumber`='$dcontact',`Email`='$demail',`Password`='$dpassword' WHERE `PatientID`='$PatientID'";

  $result = mysqli_query($conn, $dupdate);
  if ($result) {
    echo "<script>alert('Your data is successfully updated')</script>";
  } else {
    echo "<script>alert('Your data is not successfully updated')</script>";
  }
}
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
  <style>
    .bg-primary {
      background: -webkit-linear-gradient(left, #3931af, #00c6ff);
    }

    .list-group-item.active {
      z-index: 2;
      color: #fff;
      background-color: #342ac1;
      border-color: #007bff;
    }

    .text-primary {
      color: #342ac1 !important;
    }

    .btn-primary {
      background-color: #3c50c1;
      border-color: #3c50c1;
    }

    button:hover {
      cursor: pointer;
    }

    #inputbtn:hover {
      cursor: pointer;
    }
  </style>
</head>
<body style="padding-top:50px;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
    <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> Hussaini Medical Services </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container-fluid" style="margin-top:50px;">
    <h3 style="margin-left: 40%;  padding-bottom: 20px; font-family: 'IBM Plex Sans', sans-serif;"> Welcome
      &nbsp<?php echo $FirstName . " " . $LastName ?>
    </h3>
    <div class="row">
      <div class="col-md-4" style="max-width:25%; margin-top: 3%">
        <div class="list-group" id="list-tab" role="tablist">
          <a class="list-group-item list-group-item-action active" id="list-dash-list" data-toggle="list" href="#list-dash" role="tab" aria-controls="home">Dashboard</a>
          <a class="list-group-item list-group-item-action" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Book Appointment</a>
          <a class="list-group-item list-group-item-action" href="#app-hist" id="list-pat-list" role="tab" data-toggle="list" aria-controls="home">Appointment History</a>
          <a class="list-group-item list-group-item-action" href="#settings" id="doc_settings" role="tab" data-toggle="list" aria-controls="home">Settings</a>

        </div><br>
      </div>
      <div class="col-md-8" style="margin-top: 3%;">
        <div class="tab-content" id="nav-tabContent" style="width: 950px;">
          <div class="tab-pane fade  show active" id="list-dash" role="tabpanel" aria-labelledby="list-dash-list">
            <div class="container-fluid container-fullw bg-white">
              <div class="row">
                <div class="col-sm-4" style="left: 5%">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-terminal fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;"> Book My Appointment</h4>
                      <script>
                        function clickDiv(id) {
                          document.querySelector(id).click();
                        }
                      </script>
                      <p class="links cl-effect-1">
                        <a href="#list-home" onclick="clickDiv('#list-home-list')">
                          Book Appointment
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4" style="left: 10%">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-paperclip fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">My Appointments</h2>

                        <p class="cl-effect-1">
                          <a href="#app-hist" onclick="clickDiv('#list-pat-list')">
                            View Appointment History
                          </a>
                        </p>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body" >
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-gear fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;"> Settings</h4>
                      <script>
                        function clickDiv(id) {
                          document.querySelector(id).click();
                        }
                      </script>
                      <p class="links cl-effect-1">
                        <a href="#settings" onclick="clickDiv('#doc_settings')">
                          Settings
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- APPOINTMENT FORM IS STARTED -->
          <div class="tab-pane fade" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
            <div class="container-fluid">
              <div class="card">
                <div class="card-body">
                  <center>
                    <h4>Create an appointment</h4>
                  </center><br>
                  <form class="form-group" method="post" action="patient-panel.php">
                    <div class="row">

                      <?php
                      function display_c()
                      {
                        global $conn;
                        $insert = "SELECT DISTINCT city_name FROM cities";
                        $result = mysqli_query($conn, $insert);
                        while ($row = mysqli_fetch_array($result)) {
                          $City = $row['city_name'];
                          echo '<option value="' . $City . '">' . $City . '</option>';
                        }
                      }
                      function display_s()
                      {
                        global $conn;
                        $insert = "SELECT DISTINCT Specialization FROM doctor";
                        $result = mysqli_query($conn, $insert);
                        while ($row = mysqli_fetch_array($result)) {
                          $ds = $row['Specialization'];
                          echo '<option value="' . $ds . '">' . $ds . '</option>';
                        }
                      }
                      function display_docs()
                      {
                        global $conn;
                        $query = "SELECT DoctorID, CONCAT(FirstName, ' ', LastName) AS FullName, City, Specialization, Fees FROM doctor";
                        $result = mysqli_query($conn, $query);

              
                        while ($row = mysqli_fetch_array($result)){
                          $did = htmlspecialchars($row['DoctorID']);
                          $dcity = htmlspecialchars($row['City']);
                          $dname = htmlspecialchars($row['FullName']);
                          $dfees = htmlspecialchars($row['Fees']);
                          $ds = htmlspecialchars($row['Specialization']);

                          echo '<option value="' . $dname . '" data-id="' . $did . '" data-name="' . $dname . '" data-city="' . $dcity . '" data-fees="' . $dfees . '" data-spec="' . $ds . '">' . $dname . '</option>';
                        }
                      }
                      ?>
                      <div>
                        <input type="hidden" value="" name="DoctorID" id="DoctorID">
                      </div>

                      <div class="col-md-4">

                        <label for="Specialization">Specialization:</label>
                      </div>
                      <div class="col-md-8">
                        <select name="Specialization" class="form-control" id="ds">
                          <option value="" disabled selected>Select Specialization</option>
                          <?php display_s(); ?>
                        </select>
                      </div>
                      <br><br>
                      <div class="col-md-4">
                        <label for="dname">Doctors:</label>
                      </div>
                      <div class="col-md-8">
                        <select name="dname" class="form-control" id="dname" required="required">
                          <option value="" disabled selected>Select Doctor</option>
                          <?php display_docs(); ?>
                        </select>
                      </div><br /><br />
                      <div class="col-md-4">
                        <label for="Fees">Consultancy Fees</label>
                      </div>
                      <div class="col-md-8">
                        <input class="form-control" type="text" name="dfees" id="Fees" readonly="readonly" />
                      </div><br><br>
                      <div class="col-md-4">
                        <label for="city">City:</label>
                      </div>
                      <div class="col-md-8">
                        <input class="form-control" type="text" name="city" id="city" readonly="readonly" />
                      </div><br><br>
                      <div class="col-md-4">
                        <label>Appointment Date</label>
                      </div>
                      <div class="col-md-8">
                        <input type="date" class="form-control datepicker" name="appdate">
                      </div><br><br>
                      <div class="col-md-4">
                        <label>Appointment Time</label>
                      </div>
                      <div class="col-md-8">
                        <select name="apptime" class="form-control" id="apptime" required="required">
                          <option value="" disabled selected>Select Time</option>
                          <option value="08:00:00">8:00 AM</option>
                          <option value="10:00:00">10:00 AM</option>
                          <option value="12:00:00">12:00 PM</option>
                          <option value="14:00:00">2:00 PM</option>
                          <option value="16:00:00">4:00 PM</option>
                        </select>
                      </div><br><br>
                      <div class="col-md-4">
                        <input type="submit" name="appsubmit" value="Create new entry" class="btn btn-primary" id="inputbtn">
                      </div>
                      <div class="col-md-8"></div>
                    </div>
                  </form>
                  <script>
                    document.getElementById('dname').style.display = 'none';
                    document.getElementById('ds').onchange = function() {
                      let spec = this.value;
                      let dname = document.getElementById('dname');
                      let docs = [...dname.options];
                      if (spec === "") {
                        dname.style.display = 'none';
                        dname.selectedIndex = -1;
                      } else {
                        dname.style.display = '';
                        docs.forEach((el, ind, arr) => {
                          arr[ind].style.display = el.getAttribute('data-spec') === spec ? '' : 'none';
                        });
                        let visibleOptions = docs.filter(el => el.style.display === '');
                        if (visibleOptions.length > 0) {
                          dname.selectedIndex = -1;
                        }
                      }
                    };
                    document.getElementById('dname').onchange = function() {
                      let selectedOption = this.options[this.selectedIndex];
                      let fees = selectedOption.getAttribute('data-fees');
                      let did = selectedOption.getAttribute('data-id');
                      let city = selectedOption.getAttribute('data-city');
                      console.log("Selected Doctor ID:", did);
                      console.log("Selected Fees:", fees); 
                      console.log("Selected City:", city); 
                      document.getElementById('Fees').value = fees;
                      document.getElementById('DoctorID').value = did;
                      document.getElementById('city').value = city

                    };
                  </script>

                </div>
              </div>
            </div><br>
          </div>
          <!-- APPOINTMENT FORM IS ENDED -->

          <!-- APPOINTMENT HISTORY IS STARTED -->
          <div class="tab-pane fade" id="app-hist" role="tabpanel" aria-labelledby="list-pat-list">

            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">Doctor Name</th>
                  <th scope="col">Consultancy Fees</th>
                  <th scope="col">Appointment Date</th>
                  <th scope="col">Appointment Time</th>
                  <th scope="col">Current Status</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                global $conn;
                $query = "select AppointmentID,DoctorName,DoctorFees,Adate,Atime,PatientStatus,DoctorStatus from appointments where  FirstName ='$FirstName' and LastName='$LastName';";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_array($result)) {
                ?>
                  <tr>
                    <td><?php echo $row['DoctorName']; ?></td>
                    <td><?php echo $row['DoctorFees']; ?></td>
                    <td><?php echo $row['Adate']; ?></td>
                    <td><?php echo $row['Atime']; ?></td>

                    <td>
                    <?php
                      if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) {
                        echo "Active";
                      } elseif (($row['PatientStatus'] == 0) && ($row['DoctorStatus'] == 1)) {
                        echo "Cancelled by Patient";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 0)) {
                        echo "Cancelled by You";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 2)) {
                        echo "Approved";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 3)) {
                        echo "Rescheduled";
                      } else {
                        echo "Unknown Status";
                      }
                      ?>
                    </td>
                    <td>
                      <?php if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) { ?>


                        <a href="admin-panel.php?ID=<?php echo $row['AppointmentID'] ?>&cancel=update" onClick="return confirm('Are you sure you want to cancel this appointment ?')" title="Cancel Appointment" tooltip-placement="top" tooltip="Remove"><button class="btn btn-danger">Cancel</button></a>
                      <?php } else {

                        echo "Taken";
                      } ?>

                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
            <br>
          </div>
          <!-- APPOINTMENT HISTORY IS ENDED -->
           
          <!-- Settings is started -->
          <?php
          $updateread = "SELECT * FROM `patients` WHERE `PatientID` = '$PatientID'";
          $resultupdate = mysqli_query($conn, $updateread);
          if ($resultupdate) {
            $row = mysqli_fetch_array($resultupdate);
          }
          ?>
          <div class="tab-pane fade" id="settings" role="tabpanel" aria-labelledby="list-home-list">

            <form action="" method="post">
              <div class="row register-form">

                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="First Name *" name="dfname" value="<?= $row['FirstName'] ?>" required />
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Your Email *" value="<?= $row['Email'] ?>" name="demail" />
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Password *" id="dpassword" name="dpassword" value="<?= base64_decode($row['Password']) ?>" onkeyup='dcheck();' required />
                  </div>
                  <div class="form-group">
                    <div class="maxl">
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Male" <?php if ($row['Gender'] == 'Male') {
                                                                          echo "checked";
                                                                        } ?>>
                        <span> Male </span>
                      </label>
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Female" <?php if ($row['Gender'] == 'Female') {
                                                                            echo "checked";
                                                                          } ?>>
                        <span>Female </span>
                      </label>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Last Name *" name="dlname" value="<?= $row['LastName'] ?>" required />
                  </div>

                  <div class="form-group">
                    <input type="tel" minlength="11" maxlength="12" name="dcontact" class="form-control" value="<?= $row['PhoneNumber'] ?>" placeholder="Your Phone *" />
                  </div>
                
              
                </div>
                <div style="margin-left: 20px;">
                  <input type="submit" class="btn btn-primary" name="patupdate" onclick="return dchecklen();" value="Update" />
                </div>
              </div>
            </form>
          </div>
          <!-- Settings is ended -->
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.1/sweetalert2.all.min.js">
  </script>
</body>
</html>