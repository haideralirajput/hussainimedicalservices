<?php
include("conn.php");
include('newfunc.php');
if (isset($_POST['DoctorReg'])) {
  $dfname = $_POST['dfname'];
  $dlname = $_POST['dlname'];
  $dgender = $_POST['dgender'];
  $demail = $_POST['demail'];
  $ds = $_POST['ds'];
  $city = $_POST['cities'];

  $fees = $_POST['dfees'];
  $dpassword = base64_encode($_POST['dpassword']);
  $dcontact = $_POST['dcontact'];
  $dinsert = "INSERT INTO `doctor`(`FirstName`, `LastName`, `Gender`, `Specialization`,`City`, `Fees`, `PhoneNumber`, `Email`, `Password`) VALUES ('$dfname','$dlname','$dgender','$ds','$city','$fees','$dcontact','$demail','$dpassword')";

  $result = mysqli_query($conn, $dinsert);
  if ($result) {
    echo "<script>alert('Your data is successfully inserted')</script>";
  } else {
    echo "<script>alert('Your data is not successfully inserted')</script>";
  }
}
if (isset($_POST['AddCity'])) {
  $dcity = $_POST['dcity'];
  $insert = "INSERT INTO `cities`(`city_name`) VALUES ('$dcity')";
  $result = mysqli_query($conn, $insert);
  if ($result) {
    echo "<script>alert('City added successfully!');</script>";
  } else {
    echo "<script>alert('Unable to add!');</script>";
  }
}
if (isset($_GET['delete'])) {
  $query = mysqli_query($conn, "DELETE FROM doctor where DoctorID = '" . $_GET['ID'] . "'");
  if ($query) {
    echo "<script>alert('Doctor is successfully deleted');</script>";
  } else {
    echo "<script>alert('Doctor is not successfully deleted');</script>";
  }
}
if (isset($_GET['delpat'])) {
  $query = mysqli_query($conn, "DELETE FROM patients where PatientID = '" . $_GET['PID'] . "'");
  if ($query) {
    echo "<script>alert('Patient is successfully deleted');</script>";
  } else {
    echo "<script>alert('Patient is not successfully deleted');</script>";
  }
}
if (isset($_POST['docUpdate'])) {
  $dfname = $_POST['first_name'];
  $dlname = $_POST['last_name'];
  $dgender = $_POST['gender'];
  $demail = $_POST['email'];
  $ds = $_POST['specialization'];
  $dc = $_POST['city'];

  $fees = $_POST['fees'];
  $dpassword = base64_encode($_POST['password']);
  $dcontact = $_POST['contact'];
  $dupdate = "UPDATE `doctor` SET `FirstName`='$dfname',`LastName`='$dlname',`Gender`='$dgender',`Specialization`='$ds',`City`='$dc',`Fees`='$fees',`PhoneNumber`='$dcontact',`Email`='$demail',`Password`='$dpassword' WHERE `DoctorID`='$id'";

  $result = mysqli_query($conn, $dupdate);
  if ($result) {
    echo "<script>alert('Your data is successfully updated')</script>";
  } else {
    echo "<script>alert('Your data is not successfully updated')</script>";
  }
}
$citiesQuery = "SELECT `city_name` FROM `cities`";
$citiesResult = mysqli_query($conn, $citiesQuery);
$cities = [];
if ($citiesResult) {
  while ($cityRow = mysqli_fetch_assoc($citiesResult)) {
    $cities[] = $cityRow['city_name'];
  }
}
if (isset($_POST['PatientReg'])) {
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $gender = $_POST['gender'];
  $email = $_POST['email'];
  $password = base64_encode($_POST['password']);
  $contact = $_POST['contact'];
  $insert = "INSERT INTO `patients`(`FirstName`, `LastName`,`Gender`, `PhoneNumber`, `Email`, `Password`) VALUES
   ('$fname','$lname','$gender','$contact','$email','$password')";
  $result = mysqli_query($conn, $insert);
  if ($result) {
    echo "<script>alert('Your data is successfully inserted')</script>";
  } else {
    echo "<script>alert('Your data is not successfully inserted')</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <style>
    .bg-primary {
      background: -webkit-linear-gradient(left, #3931af, #00c6ff);
    }

    .col-md-4 {
      max-width: 20%;
    }

    .list-group-item.active {
      z-index: 2;
      color: #fff;
      background-color: #342ac1;
      border-color: #007bff;
    }

    .text-primary {
      color: #342ac1;
    }

    #cpass {
      display: -webkit-box;
    }

    #list-app {
      font-size: 15px;
    }

    .btn-primary {
      background-color: #3c50c1;
      border-color: #3c50c1;
    }
  </style>
</head>
<style type="text/css">
  button:hover {
    cursor: pointer;
  }

  #inputbtn:hover {
    cursor: pointer;
  }
</style>

<body style="padding-top:50px;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <a class="navbar-brand" href="#"><i class="fa fa-user-plus" aria-hidden="true"></i> Hussani Medical Services </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="logout1.php"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"></a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="container-fluid" style="margin-top:50px;">
    <h3 style="margin-left: 48%; padding-bottom: 20px;font-family: 'IBM Plex Sans', sans-serif;"> WELCOME ADMIN
    </h3>
    <div class="row">
      <div class="col-md-4" style="max-width:25%;margin-top: 3%;">
        <div class="list-group" id="list-tab" role="tablist">
          <a class="list-group-item list-group-item-action active" id="list-dash-list" data-toggle="list" href="#list-dash" role="tab" aria-controls="home">Dashboard</a>
          <a class="list-group-item list-group-item-action" href="#list-doc" id="list-doc-list" role="tab" aria-controls="home" data-toggle="list">Doctor List</a>
          <a class="list-group-item list-group-item-action" href="#list-pat" id="list-pat-list" role="tab" data-toggle="list" aria-controls="home">Patient List</a>
          <a class="list-group-item list-group-item-action" href="#list-app" id="list-app-list" role="tab" data-toggle="list" aria-controls="home">Appointment Details</a>
          <a class="list-group-item list-group-item-action" href="#list-settings" id="list-adoc-list" role="tab" data-toggle="list" aria-controls="home">Add Doctor</a>
          <a class="list-group-item list-group-item-action" href="#list-psettings" id="list-spat-list" role="tab" data-toggle="list" aria-controls="home">Add Patient</a>
          <a class="list-group-item list-group-item-action" href="#list-cities" id="list-city" role="tab" data-toggle="list" aria-controls="home">Add Cities</a>
          <a class="list-group-item list-group-item-action" href="#list-mes" id="list-mes-list" role="tab" data-toggle="list" aria-controls="home">Queries</a>

        </div><br>
      </div>
      <div class="col-md-8" style="margin-top: 3%;">
        <div class="tab-content" id="nav-tabContent" style="width: 950px;">
          <div class="tab-pane fade show active" id="list-dash" role="tabpanel" aria-labelledby="list-dash-list">
            <div class="container-fluid container-fullw bg-white">
              <div class="row">
                <div class="col-md-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-users fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">Doctor List</h4>
                      <script>
                        function clickDiv(id) {
                          document.querySelector(id).click();
                        }
                      </script>
                      <p class="links cl-effect-1">
                        <a href="#list-doc" onclick="clickDiv('#list-doc-list')">
                          View Doctors
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-users fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">Patient List</h4>

                      <p class="cl-effect-1">
                        <a href="#app-hist" onclick="clickDiv('#list-pat-list')">
                          View Patients
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 mt-5">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-paperclip fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">Appointment Details</h4>

                      <p class="cl-effect-1">
                        <a href="#app-hist" onclick="clickDiv('#list-app-list')">
                          View Appointments
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 mt-5">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-plus fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">Manage Doctors</h4>

                      <p class="cl-effect-1">
                        <a href="#app-hist" onclick="clickDiv('#list-adoc-list')">Add Doctors</a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 mt-5">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-plus fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">Manage Patients</h4>

                      <p class="cl-effect-1">
                        <a href="#app-hist" onclick="clickDiv('#list-spat-list')">Add Patients</a>
                      </p>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 mt-5">
                  <div class="panel panel-white no-radius text-center">
                    <div class="panel-body">
                      <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-plus fa-stack-1x fa-inverse"></i> </span>
                      <h4 class="StepTitle" style="margin-top: 5%;">Manage Cities</h4>
                      <p class="cl-effect-1">
                        <a href="#app-hist" onclick="clickDiv('#list-city')">Add Cities</a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Doctor list is started -->
          <div class="tab-pane fade" id="list-doc" role="tabpanel" aria-labelledby="list-home-list">
            <div class="col-md-8">
              <form class="form-group" action="doctorsearch.php" method="post">
                <div class="row">
                  <div class="col-md-10"><input type="text" name="doctor_contact" placeholder="Enter Email ID" class="form-control"></div>
                  <div class="col-md-2"><input type="submit" name="doctor_search_submit" class="btn btn-primary" value="Search"></div>
                </div>
              </form>
            </div>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Specialization</th>
                  <th scope="col">City</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Email</th>
                  <th scope="col">Fees</th>
                  <th scope="col">Password</th>
                  <th scope="col" colspan="2" class="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $insert = "SELECT * FROM doctor";
                $result = mysqli_query($conn, $insert);

                while ($row = mysqli_fetch_array($result)) {
                  $id = $row['DoctorID'];
                  $FirstName = $row['FirstName'];
                  $LastName = $row['LastName'];
                  $Gender = $row['Gender'];
                  $Specialization = $row['Specialization'];
                  $City = $row['City'];
                  $Contact = $row['PhoneNumber'];
                  $Email = $row['Email'];
                  $Fees = $row['Fees'];
                  $password = base64_decode($row['Password']);
                ?>
                  <tr>
                    <td><?php echo $FirstName; ?></td>
                    <td><?php echo $LastName; ?></td>
                    <td><?php echo $Gender; ?></td>
                    <td><?php echo $Specialization; ?></td>
                    <td><?php echo $City; ?></td>
                    <td><?php echo $Contact; ?></td>
                    <td><?php echo $Email; ?></td>
                    <td><?php echo $Fees; ?></td>
                    <td><?php echo $password; ?></td>
                    <td>
                      <a href="update_doc.php?ID=<?php echo $id; ?>&updatedoc=update" onClick="return confirm('Are you sure you want to update this doctor's details?')" title="Update Doctor" tooltip-placement="top" tooltip="Update">
                        <button class="btn btn-primary">Update</button>
                      </a>
                    </td>
                    <td>
                      <a href="admin-panel.php?ID=<?php echo $id; ?>&delete=update" onClick="return confirm('Are you sure you want to delete this doctor?')" title="Delete Doctor" tooltip-placement="top" tooltip="Delete">
                        <button class="btn btn-danger">Delete</button>
                      </a>
                    </td>
                  </tr>
                <?php
                }
                ?>
              </tbody>
            </table>
            <br>
          </div>
          <!-- Doctor list is ended-->

          <!-- Patient list is STARTED-->
          <div class="tab-pane fade" id="list-pat" role="tabpanel" aria-labelledby="list-pat-list">

            <div class="col-md-8">
              <form class="form-group" action="patientsearch.php" method="post">
                <div class="row">
                  <div class="col-md-10"><input type="text" name="patient_contact" placeholder="Enter Contact" class="form-control"></div>
                  <div class="col-md-2"><input type="submit" name="patient_search_submit" class="btn btn-primary" value="Search"></div>
                </div>
              </form>
            </div>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Email</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Password</th>
                  <th scope="col" colspan="2" class="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $insert = "select * from patients";
                $result = mysqli_query($conn, $insert);
                while ($row = mysqli_fetch_array($result)) {
                  $pid = $row['0'];
                  $fname = $row['1'];
                  $lname = $row['2'];
                  $gender = $row['3'];
                  $email = $row['5'];
                  $contact = $row['4'];
                  $password = base64_decode($row['Password']);
                ?>
                  <tr>
                    <td><?= $fname ?></td>
                    <td><?= $lname ?></td>
                    <td><?= $gender ?></td>
                    <td><?= $email ?></td>
                    <td><?= $contact ?></td>
                    <td><?= $password ?></td>
                    <td>
                      <a href="update_pat.php?PID=<?php echo $pid; ?>&updatepat=update" onClick="return confirm('Are you sure you want to update this patient's details?')" title="Update Patient" tooltip-placement="top" tooltip="Update">
                        <button class="btn btn-primary">Update</button>
                      </a>
                    </td>
                    <td>
                      <a href="admin-panel.php?PID=<?php echo $pid; ?>&delpat=update" onClick="return confirm('Are you sure you want to delete this patient?')" title="Delete Patient" tooltip-placement="top" tooltip="Delete">
                        <button class="btn btn-danger">Delete</button>
                      </a>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
            <br>
          </div>
          <!-- Patient list is ended-->

          <!-- Appointment list is started-->
          <div class="tab-pane fade" id="list-app" role="tabpanel" aria-labelledby="list-pat-list">
            <div class="col-md-8">
              <form class="form-group" action="appsearch.php" method="post">
                <div class="row">
                  <div class="col-md-10"><input type="text" name="app_contact" placeholder="Enter Contact" class="form-control"></div>
                  <div class="col-md-2"><input type="submit" name="app_search_submit" class="btn btn-primary" value="Search"></div>
                </div>
              </form>
            </div>

            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">Appt. ID</th>
                  <th scope="col">Pat. ID</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Email</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Doctor Name</th>
                  <th scope="col">Fees</th>
                  <th scope="col">Appointment Date</th>
                  <th scope="col">Appointment Time</th>
                  <th scope="col">Appointment Status</th>
                </tr>
              </thead>
              <tbody>
                <?php
                global $conn;
                $query = "select * from appointments;";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_array($result)) {
                ?>
                  <tr>
                    <td><?php echo $row['AppointmentID']; ?></td>
                    <td><?php echo $row['PatientID']; ?></td>
                    <td><?php echo $row['FirstName']; ?></td>
                    <td><?php echo $row['LastName']; ?></td>
                    <td><?php echo $row['Gender']; ?></td>
                    <td><?php echo $row['Email']; ?></td>
                    <td><?php echo $row['PhoneNumber']; ?></td>
                    <td><?php echo $row['DoctorName']; ?></td>
                    <td><?php echo $row['DoctorFees']; ?></td>
                    <td><?php echo $row['Adate']; ?></td>
                    <td><?php echo $row['Atime']; ?></td>
                    <td>
                      <?php
                      if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) {
                        echo "Active";
                      } elseif (($row['PatientStatus'] == 0) && ($row['DoctorStatus'] == 1)) {
                        echo "Cancelled by Patient";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 0)) {
                        echo "Cancelled by Doctor";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 2)) {
                        echo "Approved";
                      } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 3)) {
                        echo "Rescheduled";
                      } else {
                        echo "Unknown Status";
                      }
                      ?>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
            <br>
          </div>
          <!-- Appointment list is ended-->

          <!-- Add DOCTOR IS STARTED -->
          <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">
            <form method="post" action="">
              <div class="row register-form">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="First Name *" name="dfname" onkeydown="return dalphaOnly(event);" required />
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Your Email *" name="demail" />
                  </div>
                  <div class="form-group">
                    <select class="form-control" id="specialization" name="ds" required>
                      <option value="">Select Specialization</option>
                      <option value="Cardiology">Cardiology</option>
                      <option value="Dermatology">Dermatology</option>
                      <option value="Endocrinology">Endocrinology</option>
                      <option value="Gastroenterology">Gastroenterology</option>
                      <option value="Hematology">Hematology</option>
                      <option value="Neurology">Neurology</option>
                      <option value="Oncology">Oncology</option>
                      <option value="Orthopedics">Orthopedics</option>
                      <option value="Pediatrics">Pediatrics</option>
                      <option value="Psychiatry">Psychiatry</option>
                      <option value="Radiology">Radiology</option>
                      <option value="Surgery">Surgery</option>
                      <option value="Urology">Urology</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <select class="form-control" id="cities" name="cities" required>
                      <option value="">Select Cities</option>
                      <?php $sql = "SELECT city_name FROM cities";
                      $result = mysqli_query($conn, $sql);

                      if ($result) {

                        while ($row = mysqli_fetch_array($result)) {
                          echo '<option value="' . $row['city_name'] . '">' . $row['city_name'] . '</option>';
                        }
                      } else {
                        echo '<option value="">No Cities Available</option>';
                      }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password *" id="dpassword" name="dpassword" onkeyup='dcheck();' required />
                  </div>
                  <div class="form-group">
                    <div class="maxl">
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Male" checked>
                        <span> Male </span>
                      </label>
                      <label class="radio inline">
                        <input type="radio" name="dgender" value="Female">
                        <span>Female </span>
                      </label>
                    </div>
                    <a href="doctorlogin.php">Already have an account?</a>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Last Name *" name="dlname" onkeydown="return dalphaOnly(event);" required />
                  </div>
                  <div class="form-group">
                    <input type="tel" minlength="11" maxlength="12" name="dcontact" class="form-control" placeholder="Your Phone *" />
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Fees *" id="dfees" name="dfees" required />
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" id="dcpassword" placeholder="Confirm Password *" name="dcpassword" onkeyup='dcheck();' required /><span id='dmessage'></span>
                  </div>
                  <input type="submit" class="btnRegister btn btn-success" name="DoctorReg" onclick="return dchecklen();" value="Register" />
                </div>
              </div>
            </form>
          </div>
          <!-- Add DOCTOR IS ENDED -->

          <!-- Add PATIENT IS STARTED -->
          <div class="tab-pane fade" id="list-psettings" role="tabpanel" aria-labelledby="list-psettings-list">
            <form method="post" action="">
              <div class="row register-form">
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="First Name *" name="fname" onkeydown="return aalphaOnly(event);" required />
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Your Email *" name="email" />
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password *" id="apassword" name="password" onkeyup='acheck();' required />
                  </div>
                  <div class="form-group">
                    <div class="maxl">
                      <label class="radio inline">
                        <input type="radio" name="gender" value="Male" checked>
                        <span> Male </span>
                      </label>
                      <label class="radio inline">
                        <input type="radio" name="gender" value="Female">
                        <span>Female </span>
                      </label>
                    </div>
                    <a href="patientlogin.php">Already have an account?</a>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Last Name *" name="lname" onkeydown="return aalphaOnly(event);" required />
                  </div>
                  <div class="form-group">
                    <input type="tel" minlength="11" maxlength="12" name="contact" class="form-control" placeholder="Your Phone *" />
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" id="acpassword" placeholder="Confirm Password *" name="cpassword" onkeyup='acheck();' required /><span id='amessage'></span>
                  </div>
                  <input type="submit" class="btnRegister btn btn-success" name="PatientReg" onclick="return achecklen();" value="Register" />
                </div>
              </div>
            </form>
          </div>
          <!-- Add PATIENT IS ENDED -->

          <!-- ADD CITY IS STARTED -->

          <div class="tab-pane fade" id="list-cities" role="tabpanel" aria-labelledby="list-cities-">
            <form class="form-group" method="post" action="admin-panel.php">
              <div class="row">
                <div class="col-md-4"><label>City Name"</label></div>
                <div class="col-md-8"><input type="text" class="form-control" name="dcity" required></div><br><br>
              </div>
              <input type="submit" name="AddCity" value="Add City" class="btn btn-primary">
            </form>
          </div>
          <!-- ADD CITY IS ENDED -->

          <!-- ADD QUERIES IS STARTED -->
          <div class="tab-pane fade" id="list-mes" role="tabpanel" aria-labelledby="list-mes-list">
            <div class="col-md-8">
              <form class="form-group" action="qsearch.php" method="post">
                <div class="row">
                  <div class="col-md-10"><input type="text" name="qcontact" placeholder="Enter Contact" class="form-control"></div>
                  <div class="col-md-2"><input type="submit" name="qsearch" class="btn btn-primary" value="Search"></div>
                </div>
              </form>
            </div>
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">User Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Message</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $query = "select * from queries;";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_array($result)) {
                ?>
                  <tr>
                    <td><?php echo $row['Name']; ?></td>
                    <td><?php echo $row['Email']; ?></td>
                    <td><?php echo $row['PhoneNo']; ?></td>
                    <td><?php echo $row['Message']; ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
            <br>
          </div>
          <!-- ADD QUERIES IS ENDED -->

        </div>
      </div>
    </div>
  </div>
  <script>
    var dcheck = function() {
      if (document.getElementById('dpassword').value ==
        document.getElementById('dcpassword').value) {
        document.getElementById('dmessage').style.color = '#5dd05d';
        document.getElementById('dmessage').innerHTML = 'Matched';
      } else {
        document.getElementById('dmessage').style.color = '#f55252';
        document.getElementById('dmessage').innerHTML = 'Not Matching';
      }
    }

    function dalphaOnly(event) {
      var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 32);
    };

    function dchecklen() {
      var pass1 = document.getElementById("dpassword");
      if (pass1.value.length < 8) {
        alert("Password must be at least 8 characters long. Try again!");
        return false;
      }
    }
    var acheck = function() {
      if (document.getElementById('apassword').value ==
        document.getElementById('acpassword').value) {
        document.getElementById('amessage').style.color = '#5dd05d';
        document.getElementById('amessage').innerHTML = 'Matched';
      } else {
        document.getElementById('amessage').style.color = '#f55252';
        document.getElementById('amessage').innerHTML = 'Not Matching';
      }
    }

    function aalphaOnly(event) {
      var key = event.keyCode;
      return ((key >= 65 && key <= 90) || key == 8 || key == 32);
    };

    function achecklen() {
      var pass1 = document.getElementById("apassword");
      if (pass1.value.length < 8) {
        alert("Password must be at least 8 characters long. Try again!");
        return false;
      }
    }
  </script>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.1/sweetalert2.all.min.js"></script>
</body>

</html>