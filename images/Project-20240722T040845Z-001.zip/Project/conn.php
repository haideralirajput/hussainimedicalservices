<?php
$conn = mysqli_connect("localhost","root","","healthcaredb");
if(!$conn){
    echo "<script>alert('Connection is failed')</script>";
}
?>
