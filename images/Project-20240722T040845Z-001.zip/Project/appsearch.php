<!DOCTYPE html>
<html>
<head>
	<title>Patient Details</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
<?php
include("conn.php");

if(isset($_POST['app_search_submit'])) {
    $contact = $_POST['app_contact'];
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $stmt = $conn->prepare("SELECT * FROM appointments WHERE PhoneNumber = ?");
    if ($stmt === false) {
        die("Error preparing the statement: " . $conn->error);
    }
    $stmt->bind_param("s", $contact);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        echo "<div class='container-fluid' style='margin-top:50px;'>
              <div class='card'>
              <div class='card-body' style='background-color:#342ac1;color:#ffffff;'>
              <table class='table table-hover'>
              <thead>
                <tr>
                  <th scope='col'>First Name</th>
                  <th scope='col'>Last Name</th>
                  <th scope='col'>Email</th>
                  <th scope='col'>Contact</th>
                  <th scope='col'>Doctor Name</th>
                  <th scope='col'>Consultancy Fees</th>
                  <th scope='col'>Appointment Date</th>
                  <th scope='col'>Appointment Time</th>
                  <th scope='col'>Appointment Status</th>
                </tr>
              </thead>
              <tbody>";
        while ($row = $result->fetch_assoc()) {
            $fname = $row['FirstName'];
            $lname = $row['LastName'];
            $email = $row['Email'];
            $contact = $row['PhoneNumber'];
            $doctor = $row['DoctorName'];
            $docFees = $row['DoctorFees'];
            $appdate = $row['Adate'];
            $apptime = $row['Atime'];

            if (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 1)) {
                $appstatus = "Active";
            } elseif (($row['PatientStatus'] == 0) && ($row['DoctorStatus'] == 1)) {
                $appstatus = "Cancelled by You";
            } elseif (($row['PatientStatus'] == 1) && ($row['DoctorStatus'] == 0)) {
                $appstatus = "Cancelled by Doctor";
            } else {
                $appstatus = "Unknown";
            }
            echo "<tr>
                  <td>$fname</td>
                  <td>$lname</td>
                  <td>$email</td>
                  <td>$contact</td>
                  <td>$doctor</td>
                  <td>$docFees</td>
                  <td>$appdate</td>
                  <td>$apptime</td>
                  <td>$appstatus</td>
                </tr>";
        }
        echo "</tbody></table><center><a href='admin-panel.php' class='btn btn-light'>Back to your Dashboard</a></div></center></div></div></div>";
    } else {
        echo "<script> alert('No entries found! Please enter valid details'); 
              window.location.href = 'admin-panel.php#list-doc';</script>";
    }
    $stmt->close();
    $conn->close();
}
?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>
